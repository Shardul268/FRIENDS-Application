﻿
using Autofac;
using FriendsDataAccess;
using FriendUI.Data;
using FriendUI.Data.Lookups;
using FriendUI.Data.Repositories;
using FriendUI.View.Services;
using FriendUI.ViewModel;

namespace FriendUI.StartUp
{
    public class BootStrapper
    {
        public IContainer Bootstrap()
        {
            var bulider = new ContainerBuilder();

            bulider.RegisterType<EventAggregator>().As<IEventAggregator>().SingleInstance();

            bulider.RegisterType<FriendDbContext>().AsSelf();

            bulider.RegisterType<MainWindow>().AsSelf();

            bulider.RegisterType<MessageDialogService>().As<IMessageDialogService>();

            bulider.RegisterType<MainViewModel>().AsSelf();
            bulider.RegisterType<NavigationViewModel>().As<INavigationViewModel>();
            bulider.RegisterType<FriendDetailViewModel>().
                Keyed<IDetailViewModel>(nameof(FriendDetailViewModel));
            bulider.RegisterType<MeetingDetailViewModel>().
                Keyed<IDetailViewModel>(nameof(MeetingDetailViewModel));
            bulider.RegisterType<ProgrammingLanguageDetailViewModel>().
                Keyed<IDetailViewModel>(nameof(ProgrammingLanguageDetailViewModel));

            bulider.RegisterType<LookupDataService>().AsImplementedInterfaces();
            bulider.RegisterType<FriendRepository>().As<IFriendRepository>();
            bulider.RegisterType<MeetingRepository>().As<IMeetingRepository>();
            bulider.RegisterType<ProgrammingLanguageRepository>().As<IProgrammingLanguageRepository>();

            return bulider.Build();
        }
    }
}
