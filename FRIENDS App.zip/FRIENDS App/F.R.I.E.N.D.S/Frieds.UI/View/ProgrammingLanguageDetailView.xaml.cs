﻿using System.Windows.Controls;

namespace FriendUI.View
{
    public partial class ProgrammingLanguageDetailView : UserControl
    {
        public ProgrammingLanguageDetailView()
        {
            InitializeComponent();
        }
    }
}
