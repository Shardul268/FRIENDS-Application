﻿
namespace FriendUI.ViewModel
{
    public interface IFriendDetailViewModel : IDetailViewModel
    {
       
    }
}