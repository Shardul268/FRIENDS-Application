﻿using FriendsModel;
using FriendUI.Data.Repositories;
using FriendUI.View.Services;
using FriendUI.Wrapper;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace FriendUI.ViewModel
{
    public class ProgrammingLanguageDetailViewModel : DetailViewModelBase
    {
        private IProgrammingLanguageRepository _programmingLanguageRepository;
        private ProgrammingLanguageWrapper _selectedProgammingLanguage;

        public ProgrammingLanguageDetailViewModel(IEventAggregator eventAggregator,
            IMessageDialogService messageDialogService,
            IProgrammingLanguageRepository programmingLanguageRepository)
            : base(eventAggregator, messageDialogService)
        {
            _programmingLanguageRepository = programmingLanguageRepository;
            Title = "Programming Languages";
            ProgrammingLanguages = new ObservableCollection<ProgrammingLanguageWrapper>();

            AddProgrammingLanguageCommand = new DelegateCommand(AddProgrammingLanguageExecute);
            RemoveProgrammingLanguageCommand = new DelegateCommand(RemoveProgrammingLanguageExecute, OnRemoveCanExecute);
        }

        public ICommand AddProgrammingLanguageCommand { get; }
        public ICommand RemoveProgrammingLanguageCommand { get;}
        public ProgrammingLanguageWrapper SelectedProgrammingLanguage
        {
            get { return _selectedProgammingLanguage; }
            set
            {
                _selectedProgammingLanguage = value;
                OnPropertyChanged();
                ((DelegateCommand)RemoveProgrammingLanguageCommand).RaiseCanExecuteChanged();
            }
        }
        public ObservableCollection<ProgrammingLanguageWrapper> ProgrammingLanguages { get; }

        public async override Task LoadAsync(int id)
        {
            Id = id;
            foreach (var wrapper in ProgrammingLanguages)
            {
                wrapper.PropertyChanged -= Wrapper_PropertyChanged;
            }
            ProgrammingLanguages.Clear();
            var languages = await _programmingLanguageRepository.GetAllAsync();
            foreach (var model in languages)
            {
                var wrapper = new ProgrammingLanguageWrapper((ProgrammingLanguage)model);
                wrapper.PropertyChanged += Wrapper_PropertyChanged;
                ProgrammingLanguages.Add(wrapper);
            }
        }

        private void Wrapper_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (!HasChanges)
            {
                HasChanges = _programmingLanguageRepository.HasChanges();
            }
            if(e.PropertyName == nameof(ProgrammingLanguageWrapper.HasErrors))
            {
                ((DelegateCommand)SaveCommand).RaiseCanExecuteChanged();
            }
        }

        protected override void OnDeleteExecute()
        {
            throw new NotImplementedException();
        }

        protected override bool OnSaveCanExecute()
        {
            return HasChanges && ProgrammingLanguages.All(P => !P.HasErrors);
        }

        protected override async void OnSaveExecute()
        {
            try
            {
                await _programmingLanguageRepository.SaveAsync();
                HasChanges = _programmingLanguageRepository.HasChanges();
                RaiseCollectionSaveEvent();
            }
            catch(Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                await MessageDialogService.ShowInfoDialogAsync("Error while saving the entities, " +
                    "the data will be reloaded. Details: " + ex.Message);
                await LoadAsync(Id);
            }
        }
        private bool OnRemoveCanExecute()
        {
            return SelectedProgrammingLanguage != null;
        }

        private async void RemoveProgrammingLanguageExecute()
        {
            var isReferenced = await _programmingLanguageRepository.IsReferencedByFriendAsync(SelectedProgrammingLanguage.Id);
            if (isReferenced)
            {
                await MessageDialogService.ShowInfoDialogAsync($"The language {SelectedProgrammingLanguage.Name} can't be removed, as it is referenced by at least one friedn");
                return; 
            }

            SelectedProgrammingLanguage.PropertyChanged -= Wrapper_PropertyChanged;
            _programmingLanguageRepository.Remove(SelectedProgrammingLanguage.Model);
            ProgrammingLanguages.Remove(SelectedProgrammingLanguage);
            SelectedProgrammingLanguage = null;
            HasChanges = _programmingLanguageRepository.HasChanges();
            ((DelegateCommand)SaveCommand).RaiseCanExecuteChanged();
        }

        private void AddProgrammingLanguageExecute()
        {
            var newProgrammingLanguage = new ProgrammingLanguageWrapper(new ProgrammingLanguage());
            newProgrammingLanguage.PropertyChanged += Wrapper_PropertyChanged;
            _programmingLanguageRepository.Add(newProgrammingLanguage.Model);
            ProgrammingLanguages.Add(newProgrammingLanguage);
            newProgrammingLanguage.Name = "";
        }
    }
}
