﻿
namespace FriendUI.ViewModel
{
    public interface INavigationViewModel
    {
        Task LoadAsync();
    }
}