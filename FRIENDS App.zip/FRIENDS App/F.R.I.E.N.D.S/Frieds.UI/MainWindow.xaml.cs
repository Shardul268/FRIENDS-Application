﻿using FriendUI.Data;
using MahApps.Metro.Controls;
using System.Windows;

namespace FriendUI
{
    public partial class MainWindow : MetroWindow
    {
        private MainViewModel _viewModel;

        public MainWindow(MainViewModel ViewModel)
        {
            InitializeComponent();
            _viewModel = ViewModel;
            DataContext = ViewModel;
            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
           await _viewModel.LoadAsync();
        }

    }
}