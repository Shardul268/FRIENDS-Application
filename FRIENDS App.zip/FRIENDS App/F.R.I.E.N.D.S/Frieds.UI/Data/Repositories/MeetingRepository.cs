﻿using FriendsDataAccess;
using FriendsModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FriendUI.Data.Repositories
{
    public class MeetingRepository : GenericRepository<Meeting, FriendDbContext>, IMeetingRepository
    {
        public MeetingRepository(FriendDbContext context) : base(context)
        {

        }
        public override async Task<Meeting> GetByIdAsync(int id)
        {
            return await Context.Meetings.
                Include(m => m.friends).
                SingleAsync(m => m.Id == id);
        }

        public async Task<List<Friend>> GetAllFriendsAsync()
        {
            return await Context.Friends.ToListAsync();
        }

        public void ReloadFriendAsync(int FriendId)
        {
            var dbEntityEntry = Context.ChangeTracker.Entries<Friend>().SingleOrDefault(f => f.Entity.ID == FriendId);
            if (dbEntityEntry != null)
            {
                dbEntityEntry.Reload();
            }
        }   
    }
}
