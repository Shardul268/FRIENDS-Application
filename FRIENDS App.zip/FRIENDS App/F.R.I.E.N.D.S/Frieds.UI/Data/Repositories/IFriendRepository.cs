﻿using FriendsModel;

namespace FriendUI.Data.Repositories
{
    public interface IFriendRepository :  IGenericRepository<Friend>
    {
        void RemoveFriendPhoneNumber(FriendPhoneNumber model);
        bool HasMeetings(int friendId);
    }
}