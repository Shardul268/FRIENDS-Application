﻿using FriendsModel;

namespace FriendUI.Data.Repositories
{
    public interface IMeetingRepository : IGenericRepository<Meeting>
    {
        Task<List<Friend>> GetAllFriendsAsync();
        void ReloadFriendAsync(int Friendid);
    }
}