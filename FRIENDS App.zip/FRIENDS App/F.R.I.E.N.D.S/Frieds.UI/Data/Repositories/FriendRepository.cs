﻿using FriendsDataAccess;
using FriendsModel;
using System.Data.Entity;

namespace FriendUI.Data.Repositories
{
    public class FriendRepository : GenericRepository<Friend, FriendDbContext>, IFriendRepository
    {

        public FriendRepository(FriendDbContext context)
            : base(context)
        {
        }
        public override async Task<Friend> GetByIdAsync(int friendId)
        {
            return await Context.Friends
                .Include(f => f.PhoneNumbers)
                .SingleAsync(f => f.ID == friendId);

        }

        public void RemoveFriendPhoneNumber(FriendPhoneNumber model)
        {
            Context.FriendPhoneNumbers.Remove(model);
        }

        public bool HasMeetings(int friendId)
        {
            return (from m in Context.Meetings
                    where m.friends.Any(f => f.ID == friendId)
                    select m).Any();
        }
    }
}
