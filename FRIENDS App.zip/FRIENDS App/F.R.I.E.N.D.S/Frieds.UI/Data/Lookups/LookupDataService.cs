﻿using FriendsDataAccess;
using FriendsModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FriendUI.Data.Lookups
{
    public class LookupDataService : IFriendLookupDataService, IProgrammingLanguageLookupDataService, IMeetingLookupDataService
    {
        private Func<FriendDbContext> _context;

        public LookupDataService(Func<FriendDbContext> context)
        {
            _context = context;
        }

        public async Task<IEnumerable<LookupItem>> GetFriendLookupAsync()
        {
            using (var context = _context())
            {
                return await context.Friends.AsNoTracking()
                            .Select(f =>
                            new LookupItem
                            {
                                Id = f.ID,
                                DisplayMember = f.FirstName + " " + f.LastName,
                            })
                            .ToListAsync();
            }
        }

        public async Task<IEnumerable<LookupItem>> GetProgrammingLanguageLookupAsync()
        {
            using (var context = _context())
            {
                return await context.ProgrammingLanguage.AsNoTracking()
                            .Select(f =>
                            new LookupItem
                            {
                                Id = f.Id,
                                DisplayMember = f.Name,
                            })
                            .ToListAsync();
            }
        }

        public async Task<List<LookupItem>> GetMeeetingLookupAsync()
        {
            using(var ctx = _context())
            {
                var items = await ctx.Meetings.AsNoTracking()
                    .Select(m => 
                    new LookupItem
                    {
                        Id = m.Id,
                        DisplayMember = m.Title
                    }).ToListAsync();
                return items;
            }
        }
    }
}
