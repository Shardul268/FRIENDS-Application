﻿using FriendsModel;

namespace FriendUI.Data.Lookups
{
    public interface IMeetingLookupDataService
    {
        Task<List<LookupItem>> GetMeeetingLookupAsync();
    }
}
