﻿using Autofac;
using FriendUI.StartUp;
using System.Windows;

namespace FriendUI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var bootstrapper = new BootStrapper();
            var container = bootstrapper.Bootstrap();
            var mainwindo = container.Resolve<MainWindow>();
            mainwindo.Show();

        }

        private void Application_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show("Unexpexted error occured. Please inform admin." + 
                Environment.NewLine + e.Exception.Message, " Unexpected Error");

            e.Handled = true;
          
        }
    }

}
