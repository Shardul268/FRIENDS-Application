﻿using FriendsModel;

namespace FriendUI.Wrapper
{
    public class FriendWrapper : ModelWrapper<Friend>
    {
        public FriendWrapper(Friend model) : base(model)
        {

        }

        public int Id { get { return Model.ID; } }

        public string FirstName
        {
            get { return GetValue<string>(); }
            set{ SetValue(value); }
        }
 

        public string LastName
        {
            get { return GetValue<string>(); }
            set{ SetValue(value); }
        }


        public string Email
        {
            get { return GetValue<string>(); }
            set{ SetValue(value); }
        }

        public int? FavoriteLanguageId
        {
            get { return GetValue<int?>(); }
            set { SetValue(value); }
        }

        protected override IEnumerable<string> ValidateProperty(string propertyName)
        {
            switch (propertyName)
            {
                case nameof(FirstName):
                    if (String.Equals(FirstName, "Admin", StringComparison.OrdinalIgnoreCase))
                        yield return "FirstName is Can't be Admin";
                    break;
            }
        }
    } 
}
