﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FriendUI.Event
{
    public class OpenDetailviewEvent:PubSubEvent<OpenDetailviewEventArgs>
    {

    }

    public class OpenDetailviewEventArgs 
    {
        public int Id { get; set; }

        public string ViewModelName { get; set; }
    }

}
