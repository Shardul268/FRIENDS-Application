﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace FriendsModel
{
    public class Friend
    {
        public Friend() 
        {
            PhoneNumbers = new Collection<FriendPhoneNumber>();
            Meettings = new Collection<Meeting>();
        }
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }
        [MaxLength(50)]
        public string LastName { get; set; }
        [MaxLength(50)]
        [EmailAddress]
        public string Email {  get; set; }

        public int? FavoriteLanguageId { get; set; }
        public ProgrammingLanguage FavoriteLanguage { get; set; }
        [Timestamp]
        public byte[] RowVersion { get; set; }
        public ICollection<FriendPhoneNumber> PhoneNumbers { get; set; }
        public ICollection<Meeting> Meettings { get;  set; }
    }
}
