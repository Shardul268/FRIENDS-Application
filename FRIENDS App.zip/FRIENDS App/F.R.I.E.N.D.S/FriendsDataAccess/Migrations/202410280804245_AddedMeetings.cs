﻿namespace FriendsDataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedMeetings : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Meeting",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false, maxLength: 50),
                        DateFrom = c.DateTime(nullable: false),
                        DateTo = c.DateTime(nullable: false),
                        Friend_ID = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Friend", t => t.Friend_ID)
                .Index(t => t.Friend_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Meeting", "Friend_ID", "dbo.Friend");
            DropIndex("dbo.Meeting", new[] { "Friend_ID" });
            DropTable("dbo.Meeting");
        }
    }
}
