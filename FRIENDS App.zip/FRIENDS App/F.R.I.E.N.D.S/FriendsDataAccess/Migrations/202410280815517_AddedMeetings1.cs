﻿namespace FriendsDataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedMeetings1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Meeting", "Friend_ID", "dbo.Friend");
            DropIndex("dbo.Meeting", new[] { "Friend_ID" });
            CreateTable(
                "dbo.MeetingFriend",
                c => new
                    {
                        Meeting_Id = c.Int(nullable: false),
                        Friend_ID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Meeting_Id, t.Friend_ID })
                .ForeignKey("dbo.Meeting", t => t.Meeting_Id, cascadeDelete: true)
                .ForeignKey("dbo.Friend", t => t.Friend_ID, cascadeDelete: true)
                .Index(t => t.Meeting_Id)
                .Index(t => t.Friend_ID);
            
            DropColumn("dbo.Meeting", "Friend_ID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Meeting", "Friend_ID", c => c.Int());
            DropForeignKey("dbo.MeetingFriend", "Friend_ID", "dbo.Friend");
            DropForeignKey("dbo.MeetingFriend", "Meeting_Id", "dbo.Meeting");
            DropIndex("dbo.MeetingFriend", new[] { "Friend_ID" });
            DropIndex("dbo.MeetingFriend", new[] { "Meeting_Id" });
            DropTable("dbo.MeetingFriend");
            CreateIndex("dbo.Meeting", "Friend_ID");
            AddForeignKey("dbo.Meeting", "Friend_ID", "dbo.Friend", "ID");
        }
    }
}
